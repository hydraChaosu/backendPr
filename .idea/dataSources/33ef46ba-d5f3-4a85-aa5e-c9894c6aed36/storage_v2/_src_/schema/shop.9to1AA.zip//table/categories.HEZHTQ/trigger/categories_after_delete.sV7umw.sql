create definer = root@localhost trigger categories_after_delete
    after delete
    on categories
    for each row
BEGIN
	DELETE FROM `shopitems` WHERE `categoryId` NOT IN (SELECT DISTINCT `id` FROM `categories`);
END;

