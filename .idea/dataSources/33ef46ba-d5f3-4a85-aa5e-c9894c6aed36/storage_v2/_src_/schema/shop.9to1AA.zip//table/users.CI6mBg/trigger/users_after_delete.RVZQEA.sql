create definer = root@localhost trigger users_after_delete
    after delete
    on users
    for each row
BEGIN
	DELETE FROM `personalinfo` WHERE `userId` NOT IN (SELECT DISTINCT `id` FROM `users`);
	DELETE FROM `basketelements` WHERE `userId` NOT IN (SELECT DISTINCT `id` FROM `users`);
END;

