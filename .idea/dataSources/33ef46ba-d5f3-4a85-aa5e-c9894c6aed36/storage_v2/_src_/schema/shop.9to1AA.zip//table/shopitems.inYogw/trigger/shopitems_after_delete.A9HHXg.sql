create definer = root@localhost trigger shopitems_after_delete
    after delete
    on shopitems
    for each row
BEGIN
	DELETE FROM `basketelements` WHERE `shopItemId` NOT IN (SELECT DISTINCT `id` FROM `shopitems`);
END;

